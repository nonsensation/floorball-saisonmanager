// https://saisonmanager.de/api/v2/games.json
export interface Game
{
    id: number | null
    game_number: string | null
    start_time: string | null
    audience: number | null
}
