// https://saisonmanager.de/api/v2/leagues/1375/game_days/current/schedule.json
// https://saisonmanager.de/api/v2/leagues/1375/game_days/1/schedule.json
export interface GameDay extends Game { }
